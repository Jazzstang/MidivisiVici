#include "TransformOctaveRandomizer.h"
#include "PluginColours.h"

void TransformOctaveRandomizer::paint(juce::Graphics& g)
{
    g.fillAll(PluginColours::surface);
    g.setColour(PluginColours::onSurface);
    g.setFont(15.0f);
    g.drawText("TransformOctaveRandomizer (empty)", getLocalBounds(), juce::Justification::centred);
}

void TransformOctaveRandomizer::resized()
{
    // Rien pour l’instant
}

void TransformOctaveRandomizer::applyTransform(juce::MidiBuffer& /*midiMessages*/)
{
    // Transformation vide
}
