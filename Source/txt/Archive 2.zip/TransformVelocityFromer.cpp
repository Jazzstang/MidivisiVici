#include "TransformVelocityFormer.h"
#include "PluginColours.h"

void TransformVelocityFormer::paint(juce::Graphics& g)
{
    g.fillAll(PluginColours::surface);
    g.setColour(PluginColours::onSurface);
    g.setFont(15.0f);
    g.drawText("TransformVelocityFormer (empty)", getLocalBounds(), juce::Justification::centred);
}

void TransformVelocityFormer::resized()
{
    // Rien pour l’instant
}

void TransformVelocityFormer::applyTransform(juce::MidiBuffer& /*midiMessages*/)
{
    // Transformation vide
}
