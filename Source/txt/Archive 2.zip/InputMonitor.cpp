#include "InputMonitor.h"
#include "PluginParameters.h"

InputMonitor::InputMonitor(juce::AudioProcessorValueTreeState& vts)
    : monitor()
{
    addAndMakeVisible(titleButton);
    addAndMakeVisible(notesButton);
    addAndMakeVisible(controlsButton);
    addAndMakeVisible(monitor);

    // Attachments
    titleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        vts, ParamIDs::inputMonitorEnable, titleButton);

    notesAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        vts, ParamIDs::inputMonitorFilterNote, notesButton);

    controlsAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        vts, ParamIDs::inputMonitorFilterControl, controlsButton);
}

void InputMonitor::resized()
{
    auto area = getLocalBounds();

    auto titleArea = area.removeFromTop(24);
    titleButton.setBounds(titleArea);

    auto filterArea = area.removeFromTop(24);
    notesButton.setBounds(filterArea.removeFromLeft(80).reduced(2));
    controlsButton.setBounds(filterArea.removeFromLeft(80).reduced(2));

    monitor.setBounds(area);
}
