#pragma once
#include "TransformBase.h"

/**
 * TransformVelocityFormer
 * -----------------------
 * Module minimal de velocity shaping.
 */
class TransformVelocityFormer : public TransformBase
{
public:
    TransformVelocityFormer() = default;
    ~TransformVelocityFormer() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

    void applyTransform(juce::MidiBuffer& midiMessages) override;
};
