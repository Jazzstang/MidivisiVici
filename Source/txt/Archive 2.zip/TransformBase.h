#pragma once
#include <JuceHeader.h>

/**
 * TransformBase
 * -------------
 * Classe abstraite (base) pour toutes les transformations MIDI.
 * Chaque Transform héritera de cette classe et devra :
 *   - Implémenter applyTransform() (la logique de transformation MIDI)
 *   - Afficher son UI dans la méthode paint()
 */
class TransformBase : public juce::Component
{
public:
    TransformBase() = default;
    virtual ~TransformBase() = default;

    /**
     * applyTransform
     * --------------
     * Applique la transformation au buffer MIDI.
     * Chaque classe dérivée doit l'implémenter.
     */
    virtual void applyTransform(juce::MidiBuffer& midiMessages) = 0;
};
