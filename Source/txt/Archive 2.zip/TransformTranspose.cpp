#include "TransformTranspose.h"
#include "PluginColours.h"

TransformTranspose::TransformTranspose(juce::AudioProcessorValueTreeState& state)
    : parameters(state)
{
    // Slider de pitch
    pitchSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    pitchSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 60, 20);
    addAndMakeVisible(pitchSlider);

    // Liaison au paramètre pitchShift
    pitchAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        parameters, "pitchShift", pitchSlider);
}

void TransformTranspose::paint(juce::Graphics& g)
{
    g.fillAll(PluginColours::surface);

    g.setColour(PluginColours::onSurface);
    g.setFont(15.0f);
    g.drawText("Transpose", getLocalBounds().removeFromTop(20), juce::Justification::centred);
}

void TransformTranspose::resized()
{
    pitchSlider.setBounds(getLocalBounds().reduced(10));
}

void TransformTranspose::applyTransform(juce::MidiBuffer& midiMessages)
{
    const int semitoneShift = static_cast<int>(pitchSlider.getValue());

    juce::MidiBuffer transformed;
    for (const auto metadata : midiMessages)
    {
        auto m = metadata.getMessage();
        if (m.isNoteOnOrOff())
        {
            const int newNote = juce::jlimit(0, 127, m.getNoteNumber() + semitoneShift);
            m.setNoteNumber(newNote);
        }
        transformed.addEvent(m, metadata.samplePosition);
    }

    midiMessages.swapWith(transformed);
}
