#include "DivisiRoundRobin.h"
#include "PluginColours.h"

void DivisiRoundRobin::paint(juce::Graphics& g)
{
    g.fillAll(PluginColours::surface);
    g.setColour(PluginColours::onSurface);
    g.setFont(15.0f);
    g.drawText("DivisiRoundRobin (empty)", getLocalBounds(), juce::Justification::centred);
}

void DivisiRoundRobin::resized()
{
    // Rien pour l’instant
}

void DivisiRoundRobin::applyDivisi(juce::MidiBuffer& /*midiMessages*/)
{
    // Divisi vide
}
