#pragma once
#include "DivisiBase.h"

/**
 * DivisiOctaveDoubling
 * --------------------
 * Module minimal d'octave doubling.
 */
class DivisiOctaveDoubling : public DivisiBase
{
public:
    DivisiOctaveDoubling() = default;
    ~DivisiOctaveDoubling() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

    void applyDivisi(juce::MidiBuffer& midiMessages) override;
};
