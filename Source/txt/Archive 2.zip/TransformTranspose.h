#pragma once
#include "TransformBase.h"

/**
 * TransformTranspose
 * ------------------
 * Classe qui permet de transposer les notes MIDI d'un nombre de demi-tons.
 */
class TransformTranspose : public TransformBase
{
public:
    TransformTranspose(juce::AudioProcessorValueTreeState& state);
    ~TransformTranspose() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

    /**
     * Applique la transposition sur toutes les notes du buffer MIDI.
     */
    void applyTransform(juce::MidiBuffer& midiMessages) override;

private:
    juce::AudioProcessorValueTreeState& parameters;

    juce::Slider pitchSlider;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> pitchAttachment;
};
