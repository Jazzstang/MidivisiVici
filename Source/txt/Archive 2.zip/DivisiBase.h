#pragma once
#include <JuceHeader.h>

/**
 * DivisiBase
 * ----------
 * Classe abstraite (base) pour tous les modes Divisi.
 * Chaque Divisi héritera de cette classe et devra :
 *   - Implémenter applyDivisi() (la logique de distribution MIDI)
 *   - Gérer son UI si nécessaire
 */
class DivisiBase : public juce::Component
{
public:
    DivisiBase() = default;
    virtual ~DivisiBase() = default;

    /**
     * applyDivisi
     * -----------
     * Applique la logique de divisi au buffer MIDI.
     * Chaque classe dérivée doit l'implémenter.
     */
    virtual void applyDivisi(juce::MidiBuffer& midiMessages) = 0;
};
