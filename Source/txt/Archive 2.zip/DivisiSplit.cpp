#include "DivisiSplit.h"
#include "PluginColours.h"

void DivisiSplit::paint(juce::Graphics& g)
{
    g.fillAll(PluginColours::surface);
    g.setColour(PluginColours::onSurface);
    g.setFont(15.0f);
    g.drawText("DivisiSplit (empty)", getLocalBounds(), juce::Justification::centred);
}

void DivisiSplit::resized()
{
    // Rien pour l’instant
}

void DivisiSplit::applyDivisi(juce::MidiBuffer& /*midiMessages*/)
{
    // Divisi vide
}
