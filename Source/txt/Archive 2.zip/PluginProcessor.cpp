#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "PluginParameters.h"

//==============================================================================
// Constructeur
// Initialise l'AudioProcessor et déclare les paramètres.
//==============================================================================
MidivisiViciAudioProcessor::MidivisiViciAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
    : AudioProcessor(BusesProperties()
                     #if !JucePlugin_IsMidiEffect
                      #if !JucePlugin_IsSynth
                       .withInput("Input", juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                      ),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
#endif
{
}

//==============================================================================
// Destructeur
//==============================================================================
MidivisiViciAudioProcessor::~MidivisiViciAudioProcessor() {}


//==============================================================================
// Métadonnées Plugin
//==============================================================================

const juce::String MidivisiViciAudioProcessor::getName() const { return JucePlugin_Name; }
bool MidivisiViciAudioProcessor::acceptsMidi() const { return true; }
bool MidivisiViciAudioProcessor::producesMidi() const { return true; }
bool MidivisiViciAudioProcessor::isMidiEffect() const { return true; }
double MidivisiViciAudioProcessor::getTailLengthSeconds() const { return 0.0; }

int MidivisiViciAudioProcessor::getNumPrograms() { return 1; }
int MidivisiViciAudioProcessor::getCurrentProgram() { return 0; }
void MidivisiViciAudioProcessor::setCurrentProgram(int) {}
const juce::String MidivisiViciAudioProcessor::getProgramName(int) { return {}; }
void MidivisiViciAudioProcessor::changeProgramName(int, const juce::String&) {}


//==============================================================================
// Préparation & Libération des ressources audio
//==============================================================================

void MidivisiViciAudioProcessor::prepareToPlay(double, int) {}
void MidivisiViciAudioProcessor::releaseResources() {}

#ifndef JucePlugin_PreferredChannelConfigurations
bool MidivisiViciAudioProcessor::isBusesLayoutSupported(const BusesLayout&) const
{
    return true;
}
#endif


//==============================================================================
// Traitement audio/MIDI principal
//==============================================================================

void MidivisiViciAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    // On n'utilise pas l'audio : on l'efface
    buffer.clear();

    // ---------------------------------------------------
    // Input Monitor : affichage de l'état initial
    // ---------------------------------------------------
    const bool inputMonitorOn = parameters.getRawParameterValue("inputMonitorEnable")->load() > 0.5f;
    const bool inputFilterNote = parameters.getRawParameterValue("inputMonitorFilterNote")->load() > 0.5f;
    const bool inputFilterControl = parameters.getRawParameterValue("inputMonitorFilterControl")->load() > 0.5f;
    const bool inputFilterClock = parameters.getRawParameterValue("inputMonitorFilterClock")->load() > 0.5f;
    const bool inputFilterEvent = parameters.getRawParameterValue("inputMonitorFilterEvent")->load() > 0.5f;

    if (inputMonitorOn)
    {
        for (const auto metadata : midiMessages)
        {
            const auto& m = metadata.getMessage();

            bool keep = true;

            if (!inputFilterNote && (m.isNoteOn() || m.isNoteOff()))
                keep = false;
            if (!inputFilterControl && (m.isController() || m.isProgramChange()))
                keep = false;
            if (!inputFilterClock && (m.isMidiClock() || m.isMidiStart() || m.isMidiContinue() ||
                                      m.isMidiStop() || (m.getRawData()[0] == 0xF1) || (m.getRawData()[0] == 0xFE)))
                keep = false;
            if (!inputFilterEvent && (m.isPitchWheel() || m.isAftertouch() || m.isChannelPressure() || m.isSysEx()))
                keep = false;

            if (keep)
            {
                int start1, size1, start2, size2;
                inputFifo.prepareToWrite(1, start1, size1, start2, size2);
                if (size1 > 0)
                    inputFifoMessages[start1] = m;
                inputFifo.finishedWrite(size1);
            }
        }
    }

    // ---------------------------------------------------
    // Input Filter : modifie le buffer si activé
    // ---------------------------------------------------
    const bool learnActive = parameters.getRawParameterValue(ParamIDs::learnModeActive)->load() > 0.5f;

    if (learnActive)
    {
        for (const auto metadata : midiMessages)
        {
            const auto& m = metadata.getMessage();
            if (m.isController())
            {
                parameters.getParameter(ParamIDs::learnedCC)
                          ->setValueNotifyingHost(m.getControllerNumber() / 127.0f);
                parameters.getParameter(ParamIDs::learnedChannel)
                          ->setValueNotifyingHost((m.getChannel() - 1) / 15.0f);

                // Désactiver le mode Learn
                parameters.getParameter(ParamIDs::learnModeActive)
                          ->setValueNotifyingHost(0.0f);

                break;
            }
        }
    }

    // === Utilisation du CC appris ===
    auto learnedCCVal = static_cast<int>(parameters.getRawParameterValue(ParamIDs::learnedCC)->load() * 127.0f);
    auto learnedChannelVal = static_cast<int>(parameters.getRawParameterValue(ParamIDs::learnedChannel)->load() * 15.0f + 1);

    for (const auto metadata : midiMessages)
    {
        const auto& m = metadata.getMessage();
        if (m.isController() && m.getControllerNumber() == learnedCCVal && m.getChannel() == learnedChannelVal)
        {
            auto* muteParam = parameters.getParameter(ParamIDs::inputMute);
            bool newMute = muteParam->getValue() < 0.5f;
            muteParam->setValueNotifyingHost(newMute ? 1.0f : 0.0f);
        }
    }
    const bool inputFilterActive = parameters.getRawParameterValue("inputEnable")->load() > 0.5f;
    if (inputFilterActive)
    {
        juce::MidiBuffer filteredBuffer;

        for (const auto metadata : midiMessages)
        {
            const auto& m = metadata.getMessage();
            auto time = metadata.samplePosition;

            bool keep = true;

            // Ici tu peux ajouter des règles de filtrage du module Input Filter
            // Par exemple, toujours conserver tout :
            keep = true;

            if (keep)
                filteredBuffer.addEvent(m, time);
        }

        // Remplace le buffer uniquement si activé
        midiMessages.swapWith(filteredBuffer);
    }
    // Si non actif : ne pas toucher midiMessages

    // ---------------------------------------------------
    // Transform : traitement éventuel
    // ---------------------------------------------------
    const bool transformActive = parameters.getRawParameterValue("transformEnable")->load() > 0.5f;
    if (transformActive)
    {
        // TODO : appliquer transformation
    }

    // ---------------------------------------------------
    // Divisi : traitement éventuel
    // ---------------------------------------------------
    const bool divisiActive = parameters.getRawParameterValue("divisiEnable")->load() > 0.5f;
    if (divisiActive)
    {
        // TODO : appliquer divisi
    }

    // ---------------------------------------------------
    // Output Monitor : après tous traitements
    // ---------------------------------------------------
    const bool outputMonitorOn = parameters.getRawParameterValue("outputMonitorEnable")->load() > 0.5f;
    const bool outputFilterNote = parameters.getRawParameterValue("outputMonitorFilterNote")->load() > 0.5f;
    const bool outputFilterControl = parameters.getRawParameterValue("outputMonitorFilterControl")->load() > 0.5f;
    const bool outputFilterClock = parameters.getRawParameterValue("outputMonitorFilterClock")->load() > 0.5f;
    const bool outputFilterEvent = parameters.getRawParameterValue("outputMonitorFilterEvent")->load() > 0.5f;

    if (outputMonitorOn)
    {
        for (const auto metadata : midiMessages)
        {
            const auto& m = metadata.getMessage();

            bool keep = true;

            if (!outputFilterNote && (m.isNoteOn() || m.isNoteOff()))
                keep = false;
            if (!outputFilterControl && (m.isController() || m.isProgramChange()))
                keep = false;
            if (!outputFilterClock && (m.isMidiClock() || m.isMidiStart() || m.isMidiContinue() ||
                                       m.isMidiStop() || (m.getRawData()[0] == 0xF1) || (m.getRawData()[0] == 0xFE)))
                keep = false;
            if (!outputFilterEvent && (m.isPitchWheel() || m.isAftertouch() || m.isChannelPressure() || m.isSysEx()))
                keep = false;

            if (keep)
            {
                int start1, size1, start2, size2;
                outputFifo.prepareToWrite(1, start1, size1, start2, size2);
                if (size1 > 0)
                    outputFifoMessages[start1] = m;
                outputFifo.finishedWrite(size1);
            }
        }
    }
}


//==============================================================================
// Sauvegarde et restauration de l'état du plugin
//==============================================================================

void MidivisiViciAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void MidivisiViciAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    if (xml != nullptr && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}


//==============================================================================
juce::AudioProcessorEditor* MidivisiViciAudioProcessor::createEditor()
{
    return new MidivisiViciAudioProcessorEditor(*this);
}

bool MidivisiViciAudioProcessor::hasEditor() const
{
    return true;
}

//==============================================================================
// Point d'entrée du plugin
//==============================================================================

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new MidivisiViciAudioProcessor();
}


//==============================================================================
// Définition des paramètres
//==============================================================================

juce::AudioProcessorValueTreeState::ParameterLayout MidivisiViciAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // === Input Monitor ===
    params.push_back(std::make_unique<juce::AudioParameterBool>("inputMonitorEnable", "Input Monitor Enable", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("inputMonitorFilterNote", "Input Monitor Filter Note", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("inputMonitorFilterControl", "Input Monitor Filter Control", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("inputMonitorFilterClock", "Input Monitor Filter Clock", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("inputMonitorFilterEvent", "Input Monitor Filter Event", true));

    // === Input Filter ===
    params.push_back(std::make_unique<juce::AudioParameterBool>("inputEnable", "Input Enable", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("inputMute", "Input Mute", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        ParamIDs::learnModeActive, "Learn Mode Active", false));
    params.push_back(std::make_unique<juce::AudioParameterInt>(
        ParamIDs::learnedCC, "Learned CC", 0, 127, 0));
    params.push_back(std::make_unique<juce::AudioParameterInt>(
        ParamIDs::learnedChannel, "Learned Channel", 1, 16, 1));

    params.push_back(std::make_unique<juce::AudioParameterInt>("noteMin", "Note Min", 0, 127, 36));
    params.push_back(std::make_unique<juce::AudioParameterInt>("noteMax", "Note Max", 0, 127, 96));

    params.push_back(std::make_unique<juce::AudioParameterInt>("velocityMin", "Velocity Min", 0, 127, 0));
    params.push_back(std::make_unique<juce::AudioParameterInt>("velocityMax", "Velocity Max", 0, 127, 127));

    params.push_back(std::make_unique<juce::AudioParameterInt>("stepFilterNumerator", "Step Numerator", 1, 16, 1));
    params.push_back(std::make_unique<juce::AudioParameterInt>("stepFilterDenominator", "Step Denominator", 1, 16, 16));

    params.push_back(std::make_unique<juce::AudioParameterInt>("voiceLimit", "Voice Limit", 1, 16, 8));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "priority", "Priority", juce::StringArray{"Last", "Lowest", "Highest"}, 0));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "channel", "Channel", [] {
            juce::StringArray choices { "All" };
            for (int i = 1; i <= 16; ++i)
                choices.add("Ch " + juce::String(i));
            return choices;
        }(), 0));

    // === Transform ===
    params.push_back(std::make_unique<juce::AudioParameterBool>("transformEnable", "Transform Enable", true));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "transformMode", "Transform Mode",
        juce::StringArray{"Bypass", "Transpose", "Octave Randomizer", "Velocity Former", "Strummer"}, 0));
    params.push_back(std::make_unique<juce::AudioParameterInt>("pitchShift", "Pitch Shift", -12, +12, 0));

    // === Divisi ===
    params.push_back(std::make_unique<juce::AudioParameterBool>("divisiEnable", "Divisi Enable", true));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "divisiMode", "Divisi Mode",
        juce::StringArray{"Split", "Octave Doubling", "Drop Voicing", "Round Robin"}, 0));

    // === Output Monitor ===
    params.push_back(std::make_unique<juce::AudioParameterBool>("outputMonitorEnable", "Output Monitor Enable", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("outputMonitorFilterNote", "Output Monitor Filter Note", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("outputMonitorFilterControl", "Output Monitor Filter Control", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("outputMonitorFilterClock", "Output Monitor Filter Clock", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("outputMonitorFilterEvent", "Output Monitor Filter Event", true));

    return { params.begin(), params.end() };
}
