#pragma once
#include "DivisiBase.h"

/**
 * DivisiRoundRobin
 * ----------------
 * Module minimal de round robin.
 */
class DivisiRoundRobin : public DivisiBase
{
public:
    DivisiRoundRobin() = default;
    ~DivisiRoundRobin() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

    void applyDivisi(juce::MidiBuffer& midiMessages) override;
};
