#include "DivisiOctaveDoubling.h"
#include "PluginColours.h"

void DivisiOctaveDoubling::paint(juce::Graphics& g)
{
    g.fillAll(PluginColours::surface);
    g.setColour(PluginColours::onSurface);
    g.setFont(15.0f);
    g.drawText("DivisiOctaveDoubling (empty)", getLocalBounds(), juce::Justification::centred);
}

void DivisiOctaveDoubling::resized()
{
    // Rien pour l’instant
}

void DivisiOctaveDoubling::applyDivisi(juce::MidiBuffer& /*midiMessages*/)
{
    // Divisi vide
}
