#pragma once
#include "DivisiBase.h"

/**
 * DivisiDropVoicing
 * -----------------
 * Module minimal de drop voicing.
 */
class DivisiDropVoicing : public DivisiBase
{
public:
    DivisiDropVoicing() = default;
    ~DivisiDropVoicing() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

    void applyDivisi(juce::MidiBuffer& midiMessages) override;
};
