#pragma once

#include <JuceHeader.h>
#include "MidiMonitor.h"
#include "PluginParameters.h"

class InputMonitor : public juce::Component
{
public:
    explicit InputMonitor(juce::AudioProcessorValueTreeState& vts)
        : monitor(), parameters(vts)
    {
        // --- Bouton titre ---
        titleButton.setButtonText("Input Monitor");
        addAndMakeVisible(titleButton);
        titleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            parameters, ParamIDs::inputMonitorEnable, titleButton);

        // --- Filtres ---
        notesButton.setButtonText("Notes");
        addAndMakeVisible(notesButton);
        notesAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            parameters, ParamIDs::inputMonitorFilterNote, notesButton);

        controlsButton.setButtonText("Controls");
        addAndMakeVisible(controlsButton);
        controlsAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            parameters, ParamIDs::inputMonitorFilterControl, controlsButton);

        addAndMakeVisible(monitor);
    }

    void resized() override
    {
        auto area = getLocalBounds();
        auto titleArea = area.removeFromTop(24);
        titleButton.setBounds(titleArea);

        auto filterArea = area.removeFromTop(24);
        notesButton.setBounds(filterArea.removeFromLeft(filterArea.getWidth() / 2).reduced(2));
        controlsButton.setBounds(filterArea.reduced(2));

        monitor.setBounds(area);
    }

    /** Ajoute un message au moniteur */
    void addMessage(const juce::MidiMessage& message)
    {
        monitor.addMessage(message);
    }

    /** Lit la FIFO entrée et met à jour le moniteur */
    template <typename Fifo, typename Buffer>
    void updateFromFifo(Fifo& fifo, Buffer& buffer)
    {
        int start1, size1, start2, size2;
        fifo.prepareToRead(512, start1, size1, start2, size2);
        if (size1 > 0)
        {
            for (int i = 0; i < size1; ++i)
                addMessage(buffer[start1 + i]);
        }
        fifo.finishedRead(size1);
    }

private:
    juce::AudioProcessorValueTreeState& parameters;

    MidiMonitor monitor;

    juce::ToggleButton titleButton;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> titleAttachment;

    juce::ToggleButton notesButton, controlsButton;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> notesAttachment, controlsAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(InputMonitor)
};
