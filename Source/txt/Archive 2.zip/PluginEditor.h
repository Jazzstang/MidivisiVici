#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "PluginColours.h"
#include "PluginLookAndFeel.h"
#include "InputMonitor.h"
#include "OutputMonitor.h"
#include "MidiMonitor.h"
#include "InputFilter.h"

/**
 * Editeur principal
 * ------------------
 * Contient :
 * - 5 colonnes (Input Monitor, Input Filter, Transform, Divisi, Output Monitor)
 * - Les ToggleButtons de titre pour Transform et Divisi
 * - Les composants modulaires pour Input Monitor, Input Filter et Output Monitor
 */
class MidivisiViciAudioProcessorEditor
    : public juce::AudioProcessorEditor,
      private juce::Timer
{
public:
    MidivisiViciAudioProcessorEditor(MidivisiViciAudioProcessor&);
    ~MidivisiViciAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

    // Ajout d'un message MIDI dans le moniteur d'entrée
    void addInputMonitorMessage(const juce::MidiMessage& message);

    // Ajout d'un message MIDI dans le moniteur de sortie
    void addOutputMonitorMessage(const juce::MidiMessage& message);

private:
    MidivisiViciAudioProcessor& processor;

    // === LookAndFeel local ===
    PluginLookAndFeel lookAndFeel;

    juce::Image noiseImage;
    int noiseWidth = 0;
    int noiseHeight = 0;

    void generateNoiseImage(int width, int height);
    void timerCallback() override;

    // === Colonne 1 : Input Monitor (modulaire, avec ses filtres internes) ===
    InputMonitor inputMonitor;

    // === Colonne 2 : Input Filter (entièrement géré dans InputFilter) ===
    InputFilter inputFilterContent;

    // === Colonne 3 : Transform ===
    juce::ToggleButton transformTitleButton;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> transformEnableAttachment;
    juce::ComboBox transformModeSelector;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> transformModeAttachment;
    juce::Component transformContent; // Placeholder

    // === Colonne 4 : Divisi ===
    juce::ToggleButton divisiTitleButton;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> divisiEnableAttachment;
    juce::ComboBox divisiModeSelector;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> divisiModeAttachment;
    juce::Component divisiContent; // Placeholder

    // === Colonne 5 : Output Monitor (modulaire, avec ses filtres internes) ===
    OutputMonitor outputMonitor;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MidivisiViciAudioProcessorEditor)
};
