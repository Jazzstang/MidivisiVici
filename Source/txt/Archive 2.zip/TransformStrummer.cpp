#include "TransformStrummer.h"
#include "PluginColours.h"

void TransformStrummer::paint(juce::Graphics& g)
{
    g.fillAll(PluginColours::surface);
    g.setColour(PluginColours::onSurface);
    g.setFont(15.0f);
    g.drawText("TransformStrummer (empty)", getLocalBounds(), juce::Justification::centred);
}

void TransformStrummer::resized()
{
    // Rien pour l’instant
}

void TransformStrummer::applyTransform(juce::MidiBuffer& /*midiMessages*/)
{
    // Transformation vide
}
