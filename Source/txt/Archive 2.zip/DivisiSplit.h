#pragma once
#include "DivisiBase.h"

/**
 * DivisiSplit
 * -----------
 * Module minimal de split de plage de notes.
 */
class DivisiSplit : public DivisiBase
{
public:
    DivisiSplit() = default;
    ~DivisiSplit() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

    void applyDivisi(juce::MidiBuffer& midiMessages) override;
};
