#include "OutputMonitor.h"
#include "PluginParameters.h"

OutputMonitor::OutputMonitor(juce::AudioProcessorValueTreeState& vts)
    : monitor()
{
    addAndMakeVisible(titleButton);
    addAndMakeVisible(notesButton);
    addAndMakeVisible(controlsButton);
    addAndMakeVisible(clockButton);
    addAndMakeVisible(eventButton);
    addAndMakeVisible(monitor);

    // Attachments
    titleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        vts, ParamIDs::outputMonitorEnable, titleButton);

    notesAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        vts, ParamIDs::outputMonitorFilterNote, notesButton);

    controlsAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        vts, ParamIDs::outputMonitorFilterControl, controlsButton);

    clockAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        vts, ParamIDs::outputMonitorFilterClock, clockButton);

    eventAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        vts, ParamIDs::outputMonitorFilterEvent, eventButton);
}

void OutputMonitor::resized()
{
    auto area = getLocalBounds();

    auto titleArea = area.removeFromTop(24);
    titleButton.setBounds(titleArea);

    auto filterArea = area.removeFromTop(24);
    notesButton.setBounds(filterArea.removeFromLeft(60).reduced(2));
    controlsButton.setBounds(filterArea.removeFromLeft(60).reduced(2));
    clockButton.setBounds(filterArea.removeFromLeft(60).reduced(2));
    eventButton.setBounds(filterArea.removeFromLeft(60).reduced(2));

    monitor.setBounds(area);
}
