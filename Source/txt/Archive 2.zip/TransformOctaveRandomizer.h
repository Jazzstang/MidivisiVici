#pragma once
#include "TransformBase.h"

/**
 * TransformOctaveRandomizer
 * -------------------------
 * Module minimal de randomisation d'octave.
 */
class TransformOctaveRandomizer : public TransformBase
{
public:
    TransformOctaveRandomizer() = default;
    ~TransformOctaveRandomizer() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

    void applyTransform(juce::MidiBuffer& midiMessages) override;
};
