#include "DivisiDropVoicing.h"
#include "PluginColours.h"

void DivisiDropVoicing::paint(juce::Graphics& g)
{
    g.fillAll(PluginColours::surface);
    g.setColour(PluginColours::onSurface);
    g.setFont(15.0f);
    g.drawText("DivisiDropVoicing (empty)", getLocalBounds(), juce::Justification::centred);
}

void DivisiDropVoicing::resized()
{
    // Rien pour l’instant
}

void DivisiDropVoicing::applyDivisi(juce::MidiBuffer& /*midiMessages*/)
{
    // Divisi vide
}
