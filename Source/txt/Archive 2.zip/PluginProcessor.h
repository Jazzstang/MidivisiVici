#pragma once

#include <JuceHeader.h>

// Forward declaration de l'Editor
class MidivisiViciAudioProcessorEditor;

/**
 * ============================================================================
 * MidivisiViciAudioProcessor
 * --------------------------
 * Classe principale du processeur audio.
 * C'est ici que tu traites les messages MIDI (processBlock).
 * ============================================================================
 */
class MidivisiViciAudioProcessor : public juce::AudioProcessor
{
    //==============================================================================
    // === Paramètres et buffers partagés avec l'UI ===
public:
    MidivisiViciAudioProcessor();
    ~MidivisiViciAudioProcessor() override;

    //==============================================================================
    /** Les paramètres accessibles par l'UI */
    juce::AudioProcessorValueTreeState parameters;
    
    
    //==============================================================================
    // === FIFO pour Input Monitor ===
    juce::AbstractFifo inputFifo {512};
    juce::MidiMessage inputFifoMessages[512];

    // === FIFO pour Output Monitor ===
    juce::AbstractFifo outputFifo {512};
    juce::MidiMessage outputFifoMessages[512];

    //==============================================================================
    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
   #endif

    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    //==============================================================================
    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

private:
    /** Crée tous les paramètres du plugin */
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MidivisiViciAudioProcessor)
};
