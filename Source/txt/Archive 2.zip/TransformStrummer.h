#pragma once
#include "TransformBase.h"

/**
 * TransformStrummer
 * -----------------
 * Module minimal de strummer.
 */
class TransformStrummer : public TransformBase
{
public:
    TransformStrummer() = default;
    ~TransformStrummer() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

    void applyTransform(juce::MidiBuffer& midiMessages) override;
};
